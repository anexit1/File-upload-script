<?php
// ----------------------------------------------------------------------------
// --- FRONT ROUTES
// ----------------------------------------------------------------------------

/**
 * render home page
 * @see app/templates/index.php
 */
$app->get('/', function() use ($app, $settings) {
    $extensions = array_map( function($e) { return trim($e); },
        explode(',', $settings['file_extensions']));
    $app->render('index.php', array('size_limit'=>$settings['size_limit'], 'extensions'=>$extensions));
})->name('home');

/**
 * process upload and generate download link
 */
$app->post('/', function() use ($app, $settings) {
    $data = $app->request()->post('appData');
    $file = isset($_FILES['file'])? $_FILES['file']: null;

    $extensions = array_map( function($e) { return trim($e); },
        explode(',', $settings['file_extensions']));

    // check if there's an upload error
    if($file['error'] !== UPLOAD_ERR_OK 
    || $file == null 
    || $data == null 
    || ($file['size'] / 1000000) > $settings['size_limit']
    || in_array(pathinfo($file['name'], PATHINFO_EXTENSION), $extensions)
    ) {
        if ($app->request()->isAjax() || $app->request()->post('format') == 'json') {
            $response = array(
                'status' => 'KO',
                'url' => $app->urlFor('home'));
            echo json_encode($response);
        } else {
            $app->render('index.php', array('file_error' => true, 'size_limit'=>$settings['size_limit']));
        }
        return;
    }

    $filename = basename($file['name']);
    $tokenGenerator = new TokenGenerator(TokenGenerator::LOWER_CASE_LETTERS . TokenGenerator::NUMBERS);
    $token = $tokenGenerator->getToken(40);

    // move the uploaded file to the files path
    $filepath = $app->config('files.path') . DS . $token;
    move_uploaded_file($file['tmp_name'], $filepath);

    // check the new file size matches with the uploaded file size otherwise delete it
    if(filesize($filepath) == $file['size']) {
        $upload = ORM::for_table('uploads')->create();
        if ($data['extime'] > 0) {
            $upload->expiration_date = date('Y-m-d H:i', strtotime('+' . intval($data['extime']) . 'hours'));
        }
        $upload->expiration_downloads = intval($data['exuse']);
        $upload->filename = $file['name'];
        $upload->token = $token;

        if ($data['password'] != '') {
            $hasher = new \Phpass\Hash;
            $data['password'] = $hasher->hashPassword($data['password']);
            $upload->password = $data['password'];
        } else {
            unset($data['password']);
        }
        $upload->save();
        if ($app->request()->post('format') == 'json') {
            $response = array(
                'status' => 'OK',
                'url' => $app->urlFor('success', array('token' => $upload->token)));
            echo json_encode($response);
            return;
        } else {
            $app->redirect($app->urlFor('success', array('token'=>$upload->token)));
        }
    } else {
        unlink($filepath);
        if ($app->request()->post('format') == 'json') {
            $response = array(
                'status' => 'KO',
                'url' => $app->urlFor('home'));
                var_dump($response);
            echo json_encode($response);
            return;
        } else {
            $app->render('index.php', array('file_error' => true, 'size_limit'=>$settings['size_limit']));
        }
    }
});

/**
 * render success page after uploading a file
 */
$app->get('/success/:token', function($token) use ($app) {
    $upload = ORM::for_table('uploads')->where('token', $token)->find_one();
    if ($upload == false) {
        $app->redirect($app->urlFor('home'));
    }
    $app->render('success.php', array('token'=>$token));
})->name('success');

/**
 * show download page
 * @param string $token
 */
$app->get('/download/:token', function($token) use ($app) {
    $upload = ORM::for_table('uploads')->where('token', $token)->find_one();
    if ($upload == false
    || ($upload->expiration_downloads != 0 && $upload->expiration_downloads <= $upload->downloads)
    || ($upload->expiration_date != null && $upload->expiration_date < date('Y-m-d H:i'))
    || (!file_exists($app->config('files.path') . DS . $upload->token))
    ) {
        if ($upload != false) {
            if (file_exists($app->config('files.path') . DS . $upload->token)) {
                unlink($app->config('files.path') . DS . $upload->token);
            }
            $upload->delete();
        }
        $app->redirect($app->urlFor('expired'));
    }
    if ($upload->password != null) {

        $app->render('password_download.php', array('token'=>$token));
    } else {
        $app->render('download.php', array('token'=>$token, 'download_redirect'=>true));
    }
})->name('download');

/**
 * password download
 * @param string token
 */
$app->post('/download/:token', function($token) use ($app) {
    $upload = ORM::for_table('uploads')->where('token', $token)->find_one();
    if ($upload == false
    || ($upload->expiration_downloads != 0 && $upload->expiration_downloads <= $upload->downloads)
    || ($upload->expiration_date != null && $upload->expiration_date < date('Y-m-d H:i'))
    || (!file_exists($app->config('files.path') . DS . $upload->token))
    ) {
        if ($upload != false) {
            if (file_exists($app->config('files.path') . DS . $upload->token)) {
                unlink($app->config('files.path') . DS . $upload->token);
            }
            $upload->delete();
        }
        $app->redirect($app->urlFor('expired'));
    }

    $password = $app->request()->post('password');
    $hasher = new \Phpass\Hash;
    if (!$hasher->checkPassword($password, $upload->password)) {
        $app->render('password_download.php', array('token'=>$token, 'error'=>true));
        return;
    }

    return $app->hook('slim.after', function() use ($app, $upload) { // avoid Slim's buffer
        $file = $app->config('files.path') . DS . $upload->token;
        header('Pragma: public');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Content-Description: File Transfer');
        header('Content-Type: application/force-download');
        header('Content-Disposition: attachment; filename="' . $upload->filename . '"');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($file));
        flush();
        readfile($file);
        $upload->downloads = $upload->downloads + 1;
        $upload->save();
    });
});

/**
 * force the file download
 * @param string $token
 */
$app->get('/download/file/:token', function($token) use ($app) {
    $upload = ORM::for_table('uploads')->where('token', $token)->find_one();
    if ($upload == false 
    || ($upload->expiration_downloads != 0 && $upload->expiration_downloads <= $upload->downloads)
    || ($upload->expiration_date != null && $upload->expiration_date < date('Y-m-d H:i'))
    || (!file_exists($app->config('files.path') . DS . $upload->token))
    ) {
        if ($upload != false) {
            if (file_exists($app->config('files.path') . DS . $upload->token)) {
                unlink($app->config('files.path') . DS . $upload->token);
            }
            $upload->delete();
        }
        $app->redirect($app->urlFor('expired'));
    }

    if ($upload->password != null) {
        $app->redirect($app->urlFor('home'));
    };

    return $app->hook('slim.after', function() use ($app, $upload) { // avoid Slim's buffer
        $file = $app->config('files.path') . DS . $upload->token;
        header('Pragma: public');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Content-Description: File Transfer');
        header('Content-Type: application/force-download');
        header('Content-Disposition: attachment; filename="' . $upload->filename . '"');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($file));
        flush();
        readfile($file);
        $upload->downloads = $upload->downloads + 1;
        $upload->save();
    });
});

/**
 * render the expired page
 */
$app->get('/expired', function() use ($app) {
    $app->render('expired.php');
})->name('expired');

