<?php

// ----------------------------------------------------------------------------
// --- WEB INSTALLER ROUTES
// ----------------------------------------------------------------------------

/**
 * check if the config folder is writable and render the installer template
 * @see app/templates/installer/index.php
 */
$app->get('/install', function() use ($app, $settings) {
    if(file_exists('app' . DS . 'config' . DS . 'settings.php')) {
        return $app->notFound();
    }
    $errors = array();
    if(!is_writable('app' . DS . 'config' . DS)) {
        $errors['not_writable'] = 'The app/config/ folder must be writable.';
    } else if(!is_writable('app' . DS . 'files' . DS)) {
        $errors['not_writable'] = 'The app/files/ folder must be writable.';
    }
    $app->render('installer' . DS .'index.php', array('errors'=>$errors, 'app_data'=>$settings));
})->name('install');

/**
 * create the needed tables and the settings file with the user provided data
 */
$app->post('/install', function() use ($app, $settings, $validateData) {
    $data = $app->request()->post('app_data');
    $errors = $validateData($data);

    try { // try to create the database tables with the provided credentials
        ORM::configure(array(
            'connection_string' => 'mysql:host=' . $data['db_hostname'] . ';dbname=' . $data['db_name'],
            'username' => $data['db_username'],
            'password' => $data['db_password']
        ));
        $sql = file_get_contents('app' . DS . 'schema' . DS .'install.sql');
        ORM::for_table('uploads')->raw_execute($sql);
    } catch(Exception $e) {
        $errors['db_settings'] = 'Could not connect to the database with the provided settings.';
        $errors['db_msg'] = $e->getMessage();
    }

    if (empty($errors)) {
        $hasher = new \Phpass\Hash;
        $data['password'] = $hasher->hashPassword($data['password']);
        $data['size_limit'] = (int)(ini_get('upload_max_filesize'));
        $data['file_extensions'] = '';
        $settings = array_merge($settings, $data);
        file_put_contents('app' . DS . 'config' . DS . 'settings.php',
            '<?php $settings = ' . var_export($settings, true) . ';');
        $app->redirect($app->urlFor('home'));
    }

    $app->render('installer' . DS .'index.php', array('errors'=>$errors, 'app_data'=>$data));
});

