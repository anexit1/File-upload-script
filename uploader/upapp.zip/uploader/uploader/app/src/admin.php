<?php 


// ----------------------------------------------------------------------------
// --- ADMIN ROUTES
// ----------------------------------------------------------------------------

/**
 * render admin login page
 */
$app->get('/admin', function() use ($app) {
    $app->render('admin' . DS . 'login.php');
});

/**
 * login admin user
 */
$app->post('/admin', function() use ($app, $settings) {
    $username = $app->request()->post('username');
    $password = $app->request()->post('password');
    $hasher = new \Phpass\Hash;
    if ($username == $settings['username'] && $hasher->checkPassword($password, $settings['password'])) {
        session_cache_limiter(false);
        session_start();
        $_SESSION['admin'] = true;
        $app->redirect($app->urlFor('admin_uploads'));
    } else {
        $app->render('admin' . DS . 'login.php', array('error' => 'Wrong username or password'));
    }
});

/**
 * paginate a list of existing uploads
 */
$app->get('/admin/uploads', $isAdmin, function() use ($app) {
    $limit = 30;
    $paginator = array( 'next' => null, 'prev' => null );
    $total = ORM::for_table('uploads')->count();
    $pages = ceil(intval($total) / $limit) - 1;   
    $currentPage = intval($app->request()->get('page'));
    $offset = intval($limit * $currentPage);

    if ($total > 0 && ($currentPage > $pages || $currentPage < 0)) {
        $app->redirect($app->urlFor('admin_uploads'));
    }

    // set up the paginator links
    if ($currentPage < $pages) {
        $paginator['next'] = $currentPage + 1;
    }
    if ($currentPage > 0) {
        $paginator['prev'] = $currentPage - 1;
    }

    $uploads = ORM::for_table('uploads')
        ->limit($limit)
        ->offset($offset)
        ->order_by_desc('id')
        ->find_many();
    foreach ($uploads as $upload) {
        if (file_exists($app->config('files.path') . DS . $upload->token)) {
            $upload->file_size = filesize($app->config('files.path') . DS . $upload->token);
        } else {
            $upload->delete();
        }
    }

    $app->render('admin' . DS . 'uploads.php', array('uploads' => $uploads,'paginator' => $paginator));
})->name('admin_uploads');

/**
 * delete an existing upload by id
 * @param int $id - upload id
 */
$app->get('/admin/uploads/delete/:id', $isAdmin, function($id) use ($app) {
    $upload = ORM::for_table('uploads')->where('id', $id)->find_one();
    if ($upload) {
        if (file_exists($app->config('files.path') . DS . $upload->token)) {
            unlink($app->config('files.path') . DS . $upload->token);
        }
        $upload->delete();
    }
    $app->redirect($app->urlFor('admin_uploads'));
});

/**
 * download a file
 */
$app->get('/admin/uploads/download/:token', $isAdmin, function($token) use ($app) {
    $upload = ORM::for_table('uploads')->where('token', $token)->find_one();
    if ($upload == false) {
        $app->redirect($app->urlFor('admin_uploads'));
    }

    return $app->hook('slim.after', function() use ($app, $upload) { // avoid Slim's buffer
        $file = $app->config('files.path') . DS . $upload->token;
        header('Pragma: public');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Content-Description: File Transfer');
        header('Content-Type: application/force-download');
        header('Content-Disposition: attachment; filename="' . urlencode($upload->filename) . '"');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($file));
        flush();
        readfile($file);
    });
});

/**
 * logout admin user
 */
$app->get('/admin/logout', function() use ($app) {
	session_cache_limiter(false);
	session_start();
    session_destroy();
    $app->redirect($app->urlFor('home'));
});

/**
 * render settings page
 */
$app->get('/admin/settings', $isAdmin, function() use ($app, $settings) {
    $app->render('admin' . DS . 'settings.php', array('app_data'=>$settings));
});

/**
 * update settings
 */
$app->post('/admin/settings', $isAdmin, function() use ($app, $settings, $validateData) {
    $data = $app->request()->post('app_data');
    $errors = $validateData($data);

    if (!empty($errors)) {
        $app->render('admin' . DS . 'settings.php', array('app_data'=>$data, 'errors'=>$errors));
    } else {
        if (!empty($data['password'])) {
            $hasher = new \Phpass\Hash;
            $data['password'] = $hasher->hashPassword($data['password']);
        } else {
            unset($data['password']);
        }
        $data['file_extensions'] = str_replace(array('"', '\\'), '', strtolower($data['file_extensions']));

        $settings = array_merge($settings, $data);
        file_put_contents('app' . DS . 'config' . DS . 'settings.php',
            '<?php $settings = ' . var_export($settings, true) . ';');
        $app->redirect($app->urlFor('admin_uploads'));
    }
});

