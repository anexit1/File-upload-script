<?php

/**
 * Default settings.
 * This file is used by the web installer. You don't need to modify it.
 */
$settings = array(

    // admin panel username
    'username' => '',

    // admin panel password
    'password' => '',

    // database host
    'db_hostname' => 'localhost',

    // database name
    'db_name' => 'uploader',

    // database username
    'db_username' => '',

    // database password
    'db_password' => '',

    // max file size
    'size_limit' => '1',

    // disallowed file extensions
    'file_extensions' => '',
);
