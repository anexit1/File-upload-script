<?php require 'header.php' ?>

<div class="container" id="success">
    <p class="notice">This is your download link</p>
    <p id="download-link">
    <a href="<?php echo $site_url . $base_url . 'download/' . $token ?>">
        <?php echo $site_url . $base_url . 'download/' . $token ?>
    </a>
    </p>
    <div id="share" class="slideLeft">
        <a href="http://twitter.com/intent/tweet?url=<?php echo $site_url . $base_url . 'download/' . $token ?>"><img src="img/twitter.png" alt="Twitter"></a>
<a href="http://www.facebook.com/sharer.php?u=<?php echo $site_url . $base_url . 'download/' . $token ?>"><img src="img/facebook.png" alt="Facebook"></a>
    </div>
</div>

<?php require 'footer.php' ?>