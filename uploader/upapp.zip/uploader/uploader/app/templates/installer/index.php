<!DOCTYPE html>
<html>
<head>
    <head>
        <base href="<?php echo $base_url; ?>">
        <meta charset="utf-8" />
    <title>Uploader</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <header>
        <div class="container">
            <h1 id="installer-title">Uploader Web Installer</h1>
        </div>
    </header>
<div id="main">
    <?php if (isset($errors['not_writable'])) { 
        echo '<p class="error">' . $errors['not_writable'] . '</p>';
    } else { ?>
            <form action="" method="post" id="settings-form">
                <h1>Database settings</h1>
                <label for="db_hostname">Database hostname</label>
                <input type="text" name="app_data[db_hostname]" value="<?php echo $app_data['db_hostname'] ?>" id="db_host">
                
                <label for="db_name">Database name</label>
                <input type="text" name="app_data[db_name]" value="<?php echo $app_data['db_name'] ?>" id="db_name">
                
                <label for="db_username">Database username</label>
                <input type="text" name="app_data[db_username]" value="<?php echo $app_data['db_username'] ?>" id="db_username">

                <label for="db_password">Database password</label>
                <input type="password" name="app_data[db_password]" value="<?php echo $app_data['db_password'] ?>" id="db_password">
                <?php if (isset($errors['db_settings'])) {
                    echo '<p class="error">' . $errors['db_settings'] . '</p>';
                    echo '<p class="notice error">' . $errors['db_msg'] . '</p>';
                } ?>
                <hr>
                <h1>Administrator credentials</h1>
                <label for="username">Username</label>
                <input type="text" name="app_data[username]" value="<?php echo $app_data['username'] ?>" id="username">
                <?php if (isset($errors['username'])) {
                    echo '<p class="error">' . $errors['username'] . '</p>';
                } ?>
                <label for="password">Password</label>
                <input type="password" name="app_data[password]" value="<?php echo $app_data['password'] ?>" id="password">
                <p><input type="submit" value="Install" id="submit"></p>
            </form>
            <?php } ?>
        </div>
</body>
</html>