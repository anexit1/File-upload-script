<?php require 'header.php' ?>

<div class="container" id="expired">
    <p class="notice">Sorry, this file download has already expired.</p>
    <p><a href=" <?php echo $site_url . $base_url ?>" class="btn">Upload a new file</a></p>
</div>

<?php require 'footer.php' ?>