<?php require 'header.php' ?>

<div class="container" id="download">
    <p class="notice">
        This download link is password protected. <br> Please enter the password to continue:
    </p>
    <?php if (isset($error)) {
        echo '<p class="error">Wrong password</p>';
    } ?>
    <p>
        <form action="" method="post" id="password-download-form">
            <input type="password" name="password" value="" id="password" autofocus>
            <p><input type="submit" value="Download" class="btn"></p>
        </form>
</div>

<?php require 'footer.php' ?>