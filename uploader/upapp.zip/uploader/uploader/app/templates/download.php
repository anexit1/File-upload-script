<?php require 'header.php' ?>

<div class="container" id="download">
    <p class="notice">
        Your download will start in a few seconds, if not you can click the download button below.
    </p>
    <p><a href="<?php  echo $site_url . $base_url . '/download/file/' . $token ?>" class="btn">Download</a></p>
</div>

<?php require 'footer.php' ?>