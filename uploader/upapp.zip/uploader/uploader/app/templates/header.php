<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Uploads</title>
    <base href="<?php echo $base_url; ?>">
    <?php
        if (isset($download_redirect) && isset($token)) {
    ?>
    <meta http-equiv="refresh" content="5;url=<?php echo $site_url . $base_url . 'download/file/' . $token ?>">
    <?php } ?>
    <meta name="description" content="Uploader. Files with expiration date...">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="<?php echo $base_url ?>">Uploader</a>
            <span class="slideLeft">files with expiration date...</span>
        </div>
    </header>