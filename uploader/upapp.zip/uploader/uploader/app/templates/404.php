<?php require 'header.php' ?>

<div id="404">
    <h1>404 - Page not found</h1>
</div>

<?php require 'footer.php' ?>