<?php require 'header.php' ?>

<div class="container" id="main">
    <div class="notice" id="loader">
        Uploading your file. Please wait.
        <div id="progressBar"><p id="progressBarInner"></p></div>
    </div>
<form action="" enctype="multipart/form-data" method="post" id="upload">
    <fieldset id="filefield" class="">
        <?php if (isset($file_error) && $file_error == true) { ?>
            <p class="error">Ouch! You must select a file!</p>
        <?php } ?>
        <div id="upload-block">
            <input type="file" name="file" value="" id="file">
        </div>
    </fieldset>

    <fieldset id="expiration">
        <div>
            <select name="appData[extime]" id="extime">
                <option value="0">Never expires on time</option>
                <option value="24">Expires after one day</option>
                <option value="72">Expires after three days</option>
                <option value="168">Expires after seven days</option>
                <option value="720">Expires after thirty days</option>
                <option value="2160">Expires after ninety days</option>
            </select>
        </div><div>
            <select name="appData[exuse]" id="exuse">
                <option value="0">Never expires on downloads</option>
                <option value="1">Expires after one download</option>
                <option value="10">Expires after ten downloads</option>
                <option value="100">Expires after one hundred downloads</option>
                <option value="1000">Expires after one thousand downloads</option>
            </select>
        </div>
    </fieldset>

    <fieldset id="passwordBlock">
        <button id="passwordBtn">Add password</button>
        <input type="password" name="appData[password]" value="" id="password">
    </fieldset>

    <p class="clearfix submit"><input type="submit" class="btn" value="Upload" id="submit"></p>
</form>
</div>

<script>
var file = null;
var extensions = [<?php echo implode(',', array_map( function($e) { return '"' . $e . '"'; },$extensions)); ?>];
var passwordBtn = document.getElementById('passwordBtn');
var passwordField = document.getElementById('password');

passwordBtn.onclick = function(e) {
    this.style.display = 'none';
    passwordField.style.display = 'block';
    passwordField.focus();
    e.preventDefault();
    e.stopPropagation();
    return false;
};

var uploadBtn = document.getElementById('upload-block');
var fileInput = document.getElementById('file');
var uploadBlock = document.getElementById('upload-block');
uploadBtn.onclick = function(e) {
    document.getElementById("file").click()
}
fileInput.onchange = function(e) {
    uploadBlock.className = 'changed';
    file = this.files[0];
}

var show = function() {
    var d = document.getElementById("main");
    d.className = d.className + " ready";
};

uploadBtn.addEventListener('dragover', function(e) {
    e.preventDefault();
    e.stopPropagation();
    return false;
}, false);

uploadBtn.addEventListener('drop', function(e) {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.files.length == 1) {
        file = e.dataTransfer.files[0];
        uploadBlock.className = 'changed';
    }
    return false;
}, false);

var img = new Image();
img.onload = show;
img.src = "<?php echo $base_url ?>img/disk.png";

var imgCheck = new Image();
imgCheck.src = "<?php echo $base_url ?>img/check.png";

submit.onclick = function(e) {
    if (file == null) {
        alert('Ouch! You must select a file!');
        return false;
    }

    var extension = file.name.split('.').pop().toLowerCase();
    if (extensions.indexOf(extension) >= 0) {
        alert("D'oh! That file extension is not allowed!");
        return false;
    }

    if (!window.FormData) {
        return true;
    }

    if ((file.size / 1000000) > <?php echo (int)($size_limit); ?>) {
        alert('The file is too big!!');
        return false;
    }

    var upload = document.getElementById('upload');
    var loader = document.getElementById('loader');
    var progress = document.getElementById('progressBarInner');
    var submit = document.getElementById('submit');
    var extime = document.getElementById('extime');
    var exuse = document.getElementById('exuse');

    upload.className = 'submitted';
    loader.className = loader.className + ' active';

    var formData = new FormData();
    formData.append("appData[extime]", extime.options[extime.selectedIndex].value); 
    formData.append("appData[exuse]", exuse.options[exuse.selectedIndex].value);
    formData.append("appData[password]", passwordField.value);
    formData.append("format", 'json');
    formData.append("file", file);

    var xhr = new XMLHttpRequest();
    xhr.upload.addEventListener("progress", function(e) {
        var loaded = Math.round(e.loaded * 100 / e.total);
        progress.style.width = loaded + "%";
    }, false);
    xhr.open("POST", "");
    xhr.send(formData);
    xhr.onreadystatechange = function(e) {
        if(this.readyState == 4) {
            try {
                var response = JSON.parse(this.responseText); 
            } catch (SyntaxError) {
                var response = {
                    'status': 'KO',
                    'url': '<?php echo $base_url ?>'
                };
            }
            if (response.status == 'KO') {
                alert('Ouch! Your file could not be uploaded!')
            }
            window.location = response.url;
        }
    }
    return false;
}
</script>

<?php require 'footer.php' ?>
