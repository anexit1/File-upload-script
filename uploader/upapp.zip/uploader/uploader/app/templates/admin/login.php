<!DOCTYPE html>
<html>
<head>
    <base href="<?php echo $base_url; ?>">
    <meta charset="utf-8">
    <title>Uploader Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <form action="" method="post" id="login-form">
        <h1 id="login-title">Uploader</h1>
        <?php if (isset($error)) {
            echo '<p id="login-error" class="error">' . $error . '</p>';
        } ?>
        <label for="username">Username</label>
        <input type="text" name="username" value="" id="username" autofocus>
        <label for="password">Password</label>
        <input type="password" name="password" value="" id="password">
        <p><input type="submit" value="Login" id="login-btn"></p>
    </form>
</body>
</html>