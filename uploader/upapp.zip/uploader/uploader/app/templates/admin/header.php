<!DOCTYPE html>
<html>
<head>
    <base href="<?php echo $base_url; ?>">
    <meta charset="utf-8">
    <title>Uploader Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <header>
        <div class="container">
            <h1><a href="<?php echo $base_url ?>admin/uploads">Uploads</a></h1>
            <nav>
                <a href="<?php echo $base_url ?>admin/settings">Settings</a>
                <a href="<?php echo $base_url ?>admin/logout">Logout</a>
            </nav>
        </div>
    </header>
