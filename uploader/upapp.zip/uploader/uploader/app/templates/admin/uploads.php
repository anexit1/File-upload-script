<?php include 'header.php' ?>

<div id="main">
<?php if (count($uploads) == 0) { ?>
    <p class="empty">There are no uploaded files.</p>
<?php } else { ?>
    <table>
        <thead>
            <tr>
                <td>Filename</td>
                <td>Expiration</td>
                <td class="downloads">Downloads</td>
                <td class="icon">Download</td>
                <td class="icon">Delete</td>
            </tr>
        </thead>
        <tbody>

    <?php foreach ($uploads as $upload) { ?>

    <tr>
        <td class="filename">
            <a href="<?php echo $base_url . 'success/' . $upload->token ?>" target="blank">
                <?php echo $upload->filename ?>
            </a>
            <p>
                <small><?php  echo $upload->file_size / 1000; ?> KB</small>
                <?php if ($upload->password != null) { ?>
                    <img src="img/lock.png" alt="password protected">
                <?php  } ?>
            </p>
        </td>
        <td>
            <p>
            <?php
            if ($upload->expiration_date == null) {
                echo 'Never expires on time';
            } else {
                echo 'Expires on ' . date('Y-m-d', strtotime($upload->expiration_date));
            }
            ?>
            </p>
            <p>
            <?php 
            if ($upload->expiration_downloads == 0) {
                echo 'Never expires on downloads';
            } else {
                echo 'Expires after ' . $upload->expiration_downloads . ' download';
                if ($upload->expiration_downloads != 1) echo 's';
            }
            ?>
            </p>
        </td>
        <td class="downloads">
            <?php echo $upload->downloads ?>
        </td>
        <td class="icon">
            <a href="<?php echo $base_url ?>admin/uploads/download/<?php echo $upload->token ?>"><img src="img/download.png" alt="download"></a>
        </td>
        <td class="icon">
            <a href="<?php echo $base_url ?>admin/uploads/delete/<?php echo $upload->id ?>"><img src="img/delete.png" alt="delete"></a>
        </td>
    </tr>
    <?php 
        }
    ?>
    </tbody>
    </table>
    <div id="paginator">
        <?php if ($paginator['prev'] !== null) { ?>
            <a href="<?php echo $base_url ?>admin/uploads?page=<?php echo $paginator['prev'] ?>" id="prev">&lt;&lt;</a>
        <?php } ?>
        <?php if ($paginator['next'] !== null) { ?>
            <a href="<?php echo $base_url ?>admin/uploads?page=<?php echo $paginator['next'] ?>" id="next">&gt;&gt;</a>
        <?php } ?>

    </div>

    <?php } ?>
</div>

<?php include 'footer.php' ?>