<?php include 'header.php' ?>

<div id="main">
    <form action="" method="post" id="settings-form">
        <h1>Administrator credentials</h1>
        <p class="notice">Leave the password field blank to keep the same password.</p>
        <label for="username">Username</label>
        <input type="text" name="app_data[username]" value="<?php echo $app_data['username'] ?>" id="username">
        <?php if (isset($errors['username'])) {
            echo '<p class="error">' . $errors['username'] . '</p>';
        } ?>
        <label for="password">Password</label>
        <input type="password" name="app_data[password]" value="" id="password">
        <hr>
        <h1>File extension filder</h1>
        <p class="notice">Here you can add a list of comma separated extensions you don't want to allow, files with this extensions won't be uploaded to the server. Leave it blank to allow all file extensions.</p>
        <label for="file_extensions">File Extensions</label>
        <input type="text" name="app_data[file_extensions]" value="<?php echo $app_data['file_extensions'] ?>" id="file_extensions">
        <hr>
        <h1>Server settings</h1>
        <p class="notice">The maximum upload file size allowed by the server is <b><?php echo ini_get('upload_max_filesize') ?></b>. <br>You can change it in your server's php.ini file.</p>

        <label for="size_limit">Maximum file size limit in MB</label>
        <select name="app_data[size_limit]" id="size_limit">
            <?php for ($i=1;$i<=ini_get('upload_max_filesize');$i++) { ?>
                <option value="<?php echo $i?>" <?php if ($i == $app_data['size_limit']) echo 'selected' ?>><?php echo $i ?></option>
            <?php } ?>
        </select>
        <p><input type="submit" value="Submit" id="submit"></p>
    </form>
</div>

<?php include 'footer.php' ?>
