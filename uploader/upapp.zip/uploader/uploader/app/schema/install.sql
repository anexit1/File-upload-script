--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(500) NOT NULL,
  `expiration_date` datetime,
  `expiration_downloads` int(11),
  `downloads` int(11) NOT NULL DEFAULT '0',
  `token` varchar(60) NOT NULL,
  `password` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `token` (`token`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

